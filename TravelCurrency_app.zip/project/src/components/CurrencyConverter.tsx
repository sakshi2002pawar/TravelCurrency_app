import React, { useState } from 'react';
import { ArrowRightLeft } from 'lucide-react';
import { ConversionResult } from '../types';

interface Props {
  currencies: string[];
  onConvert: (amount: number, from: string, to: string) => Promise<ConversionResult>;
}

export default function CurrencyConverter({ currencies, onConvert }: Props) {
  const [amount, setAmount] = useState<number>(1);
  const [fromCurrency, setFromCurrency] = useState<string>('USD');
  const [toCurrency, setToCurrency] = useState<string>('EUR');
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const conversionResult = await onConvert(amount, fromCurrency, toCurrency);
      setResult(conversionResult);
    } catch (error) {
      console.error('Conversion failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const swapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Currency Converter</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-4">
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
              Amount
            </label>
            <input
              id="amount"
              type="number"
              min="0.01"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <label htmlFor="fromCurrency" className="block text-sm font-medium text-gray-700 mb-1">
                From
              </label>
              <select
                id="fromCurrency"
                value={fromCurrency}
                onChange={(e) => setFromCurrency(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {currencies.map((currency) => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={swapCurrencies}
              className="mt-6 p-2 rounded-full hover:bg-gray-100"
              aria-label="Swap currencies"
            >
              <ArrowRightLeft className="h-5 w-5 text-gray-600" />
            </button>

            <div className="flex-1">
              <label htmlFor="toCurrency" className="block text-sm font-medium text-gray-700 mb-1">
                To
              </label>
              <select
                id="toCurrency"
                value={toCurrency}
                onChange={(e) => setToCurrency(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {currencies.map((currency) => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full btn btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Converting...' : 'Convert'}
        </button>
      </form>

      {result && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-lg font-medium text-gray-900">
            {result.amount} {result.from} =
          </p>
          <p className="text-3xl font-bold text-blue-600">
            {result.result.toFixed(2)} {result.to}
          </p>
          <p className="text-sm text-gray-500 mt-2">
            1 {result.from} = {(result.result / result.amount).toFixed(4)} {result.to}
          </p>
        </div>
      )}
    </div>
  );
}