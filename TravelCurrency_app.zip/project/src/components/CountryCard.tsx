import React from 'react';
import { Country } from '../types';

interface Props {
  country: Country;
  onClick: () => void;
}

export default function CountryCard({ country, onClick }: Props) {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transform transition-transform hover:scale-105"
    >
      <img
        src={country.flag}
        alt={`${country.name} flag`}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-bold text-gray-800">{country.name}</h3>
        <p className="text-gray-600 mt-1">Currency: {country.currency}</p>
        <p className="text-gray-500 mt-2 line-clamp-2">{country.description}</p>
      </div>
    </div>
  );
}