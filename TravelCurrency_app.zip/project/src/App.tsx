import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Globe, Search } from 'lucide-react';
import { Country, ConversionResult } from './types';
import CurrencyConverter from './components/CurrencyConverter';
import CountryCard from './components/CountryCard';

const COUNTRIES: Country[] = [
  {
    name: 'India',
    code: 'IN',
    currency: 'INR',
    flag: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800',
    description: 'A vibrant country known for its rich culture, diverse landscapes, and ancient traditions.',
  },
  {
    name: 'United States',
    code: 'US',
    currency: 'USD',
    flag: 'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?w=800',
    description: 'Home to diverse landscapes, from bustling cities to natural wonders.',
  },
  {
    name: 'Japan',
    code: 'JP',
    currency: 'JPY',
    flag: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800',
    description: 'A fascinating blend of ancient traditions and modern technology.',
  },
  {
    name: 'France',
    code: 'FR',
    currency: 'EUR',
    flag: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800',
    description: 'Known for its art, culture, cuisine, and iconic landmarks.',
  },
  {
    name: 'Australia',
    code: 'AU',
    currency: 'AUD',
    flag: 'https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?w=800',
    description: 'A continent of unique wildlife, stunning beaches, and vibrant cities.',
  },
  // Add more countries as needed
];

const CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'INR', 'CNY'];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);

  const filteredCountries = COUNTRIES.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleConvert = async (amount: number, from: string, to: string): Promise<ConversionResult> => {
    try {
      // Note: In a production app, you would use a real API key and proper error handling
      const response = await axios.get(
        `https://api.exchangerate-api.com/v4/latest/${from}`
      );
      
      const rate = response.data.rates[to];
      return {
        amount,
        from,
        to,
        result: amount * rate
      };
    } catch (error) {
      console.error('Error converting currency:', error);
      return {
        amount,
        from,
        to,
        result: 0
      };
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Globe className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">TravelCurrency</span>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search countries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <CurrencyConverter onConvert={handleConvert} currencies={CURRENCIES} />
            
            {selectedCountry && (
              <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold mb-4">{selectedCountry.name}</h2>
                <img
                  src={selectedCountry.flag}
                  alt={`${selectedCountry.name} landscape`}
                  className="w-full h-64 object-cover rounded-lg mb-4"
                />
                <p className="text-gray-700">{selectedCountry.description}</p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {filteredCountries.map((country) => (
              <CountryCard
                key={country.code}
                country={country}
                onClick={() => setSelectedCountry(country)}
              />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;