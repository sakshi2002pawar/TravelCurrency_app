export interface Country {
  name: string;
  code: string;
  currency: string;
  flag: string;
  description: string;
}

export interface ConversionResult {
  amount: number;
  from: string;
  to: string;
  result: number;
}